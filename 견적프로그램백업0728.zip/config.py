import os

# 기본 경로 설정
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CREDS_PATH = os.getenv('CREDS_PATH', os.path.join(CURRENT_DIR, "creds.json"))

# 셀 매핑 설정 (기존 견적서용)
CELL_MAP = {
    "estimate_date": "F5",
    "estimate_number": "F6",
    "supplier_person": "B11",
    "supplier_contact": "B12",
    "receiver_company": "D10",
    "receiver_person": "E11",
    "receiver_contact": "E12",
    "delivery_date": "B30",
}

# 제품 정보 셀 매핑 (기존 견적서용)
for i in range(8):
    CELL_MAP[f"products[{i}][type]"] = f"A{15+i}"
    CELL_MAP[f"products[{i}][name]"] = f"B{15+i}"
    CELL_MAP[f"products[{i}][detail]"] = f"C{15+i}"
    CELL_MAP[f"products[{i}][qty]"] = f"D{15+i}"
    CELL_MAP[f"products[{i}][price]"] = f"E{15+i}"
    CELL_MAP[f"products[{i}][total]"] = f"F{15+i}"
    CELL_MAP[f"products[{i}][note]"] = f"G{15+i}"

# 새로운 데이터 수집용 스프레드시트 설정
DATA_COLLECTION_SHEET_ID = "1lanDTaqOzAXFQaZcqj91X6kknbpHXREH3bLQrTeVq6Q"

# 데이터 수집용 스프레드시트 컬럼 매핑 (A1:S1 헤더 기준)
DATA_COLLECTION_COLUMNS = {
    "A": "estimate_date",      # 견적일자
    "B": "estimate_number",    # 견적번호
    "C": "supplier_person",    # 견적담당자
    "D": "receiver_company",   # 수신자-회사명
    "E": "receiver_person",    # 수신자-담당자
    "F": "receiver_contact",   # 수신자-연락처
    "G": "product_category",   # 견적제품
    "H": "products[0]_name",   # 제품1
    "I": "products[1]_name",   # 제품2
    "J": "products[2]_name",   # 제품3
    "K": "products[3]_name",   # 제품4
    "L": "products[4]_name",   # 제품5
    "M": "products[5]_name",   # 제품6
    "N": "products[6]_name",   # 제품7
    "O": "products[7]_name",   # 제품8
    "P": "final_total",        # 최종견적(VAT포함)
    "Q": "delivery_date",      # 납기일
    "R": "estimate_link",      # 견적파일(엑셀)
    "S": "pdf_link"            # 견적파일(PDF)
}

# API 설정
API_HOST = os.getenv('API_HOST', 'localhost')
API_PORT = int(os.getenv('API_PORT', 9000))

# Pipedrive API 설정
try:
    from pipedrive_config_local import *
except ImportError:
    # 로컬 설정 파일이 없으면 기본값 사용
    PIPEDRIVE_API_TOKEN = 'your_pipedrive_api_token_here'
    PIPEDRIVE_DOMAIN = 'your_pipedrive_domain.pipedrive.com'
    PIPEDRIVE_PIPELINE_ID = '1'
    PIPEDRIVE_STAGE_ID = '1'
    PIPEDRIVE_USER_MAPPING = {
        "이훈수": 23659842,
        "차재원": 23787233,
        "장진호": 23823247,
        "하철용": 23839131,
        "노재익": 23839109,
        "전준영": 23839164,
    } 