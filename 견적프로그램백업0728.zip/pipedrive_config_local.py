# Pipedrive API 설정
# 이 파일을 복사해서 pipedrive_config_local.py로 만들고 실제 값들을 입력하세요

# Pipedrive API 토큰 (Pipedrive 설정 > 개인 설정 > API에서 확인)
PIPEDRIVE_API_TOKEN = "641d9cc3317c7e05d50bd95210d0747a65d7599f"

# Pipedrive 도메인 (예: company.pipedrive.com)
PIPEDRIVE_DOMAIN = "anytronkr.pipedrive.com"

# 견적서생성 파이프라인 ID (Pipedrive에서 파이프라인 ID 확인)
PIPEDRIVE_PIPELINE_ID = "4"

# 첫 번째 스테이지 ID (파이프라인의 첫 번째 단계 ID)
# 이제 담당자별로 동적으로 매핑하므로 기본값만 설정
PIPEDRIVE_STAGE_ID = "47"

# 담당자별 Pipedrive 사용자 ID 매핑
# Pipedrive에서 각 사용자의 ID를 확인하여 입력하세요
PIPEDRIVE_USER_MAPPING = {
    "이훈수": 23659842,
    "차재원": 23787233,
    "장진호": 23823247,
    "하철용": 23839131,
    "노재익": 23839109,
    "전준영": 23839164,
} 