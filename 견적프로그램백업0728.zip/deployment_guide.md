# 워드프레스 + FastAPI 배포 가이드

## 1. VPS 서버 설정 (권장)

### 1.1 서버 준비
```bash
# Ubuntu 20.04+ 기준
sudo apt update
sudo apt install python3 python3-pip nginx git
```

### 1.2 프로젝트 배포
```bash
# 프로젝트 클론
git clone [your-repo] /var/www/estimate-api
cd /var/www/estimate-api

# 의존성 설치
pip3 install -r requirements.txt

# 서비스 파일 생성
sudo nano /etc/systemd/system/estimate-api.service
```

### 1.3 systemd 서비스 설정
```ini
[Unit]
Description=Estimate API
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/estimate-api
Environment="PATH=/var/www/estimate-api/venv/bin"
ExecStart=/var/www/estimate-api/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

### 1.4 Nginx 설정
```nginx
server {
    listen 80;
    server_name api.bitekps.com;  # 또는 서브도메인

    location / {
        proxy_pass http://127.0.0.1:9000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 1.5 서비스 시작
```bash
sudo systemctl enable estimate-api
sudo systemctl start estimate-api
sudo systemctl restart nginx
```

## 2. 워드프레스 연동

### 2.1 estimate_form.html을 워드프레스 페이지에 임베딩
```php
<!-- 워드프레스 페이지 템플릿 -->
<?php
/*
Template Name: 견적서 작성
*/

get_header(); ?>

<div class="estimate-form-container">
    <iframe 
        src="https://api.bitekps.com/estimate_form.html" 
        width="100%" 
        height="800px" 
        frameborder="0"
        style="border: none; width: 100%; min-height: 800px;">
    </iframe>
</div>

<?php get_footer(); ?>
```

### 2.2 JavaScript로 API 연동
```javascript
// 워드프레스 페이지에 추가할 JavaScript
const API_BASE_URL = 'https://api.bitekps.com';

// 견적서 데이터 전송
async function submitEstimate(data) {
    try {
        const response = await fetch(`${API_BASE_URL}/estimate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 미리보기 페이지로 이동
            window.location.href = `${API_BASE_URL}/preview.html?id=${result.fileId}`;
        }
    } catch (error) {
        console.error('견적서 제출 실패:', error);
    }
}
```

## 3. CORS 설정

### 3.1 main.py CORS 설정 수정
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://bitekps.com",
        "https://www.bitekps.com",
        "http://localhost:3000"  # 개발용
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)
```

## 4. 환경 변수 설정

### 4.1 .env 파일 생성
```env
# Google API 설정
GOOGLE_CREDENTIALS_FILE=creds.json
GOOGLE_SHEETS_TEMPLATE_ID=your_template_id

# Pipedrive 설정
PIPEDRIVE_API_TOKEN=your_token
PIPEDRIVE_DOMAIN=your_domain

# 서버 설정
HOST=0.0.0.0
PORT=9000
```

## 5. 보안 설정

### 5.1 SSL 인증서 설정
```bash
# Let's Encrypt 설치
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d api.bitekps.com
```

### 5.2 방화벽 설정
```bash
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 22
sudo ufw enable
```

## 6. 모니터링 및 로그

### 6.1 로그 설정
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/estimate-api.log'),
        logging.StreamHandler()
    ]
)
```

### 6.2 로그 모니터링
```bash
# 실시간 로그 확인
sudo tail -f /var/log/estimate-api.log

# 서비스 상태 확인
sudo systemctl status estimate-api
```

## 7. 백업 및 유지보수

### 7.1 자동 백업 스크립트
```bash
#!/bin/bash
# /var/www/backup-estimate-api.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/var/backups/estimate-api"

mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/estimate-api-$DATE.tar.gz /var/www/estimate-api

# 30일 이상 된 백업 삭제
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

### 7.2 cron 작업 등록
```bash
# crontab -e
0 2 * * * /var/www/backup-estimate-api.sh
```

## 8. 성능 최적화

### 8.1 Gunicorn 사용 (선택사항)
```bash
pip install gunicorn

# gunicorn.conf.py
bind = "127.0.0.1:9000"
workers = 4
worker_class = "uvicorn.workers.UvicornWorker"
```

### 8.2 캐싱 설정
```python
from fastapi_cache import FastAPICache
from fastapi_cache.backends.redis import RedisBackend

@app.on_event("startup")
async def startup():
    redis = aioredis.from_url("redis://localhost", encoding="utf8")
    FastAPICache.init(RedisBackend(redis), prefix="fastapi-cache")
``` 